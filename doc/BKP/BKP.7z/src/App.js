import './App.css';
import Hello from './components/Hello';

function App() {
  return (
    // eslint-disable-next-line react/react-in-jsx-scope
    <Hello />
  );
}

export default App;
